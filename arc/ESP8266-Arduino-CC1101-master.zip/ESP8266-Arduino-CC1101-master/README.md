Port of panStamp's CC1101 Library to ESP8266.
